#include <iostream>
#include <stdlib.h>
#include <math.h>
#include<GL/gl.h>
#include <GL/glut.h>
#include "Renderer.h"
#include "Car.h"

using namespace std;

// Global Variables
float _angle = 0.0, xAxis = -5.0f;
float _cameraAngle = 0.0;

//Draws the 3D scene
void drawScene() {
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glMatrixMode(GL_MODELVIEW); //Switch to the drawing perspective
	glLoadIdentity(); //Reset the drawing perspective
	glRotatef(-_cameraAngle, 0.0, 1.0, 0.0); //Rotate the camera
	glTranslatef(0.0, 0.0, -7.0); //Move forward 5 units

    Car car(_angle, xAxis);

	glutSwapBuffers();
}

void update(int value)
 {
    _angle += 2.0f;
	xAxis += 0.05f;

	if (_angle > 360)
    {
		_angle -= 360;
	}

    if(xAxis > 5.0)
    {
        xAxis = -5.0f;

    }

	glutPostRedisplay();  //Tells GLUT that the display has changed
	glutTimerFunc(25, update, 0); //Tells GLUT to call update again in 10 milliseconds

}

//Called when the window is resized
void handleResize(int w, int h) {
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0, (double)w / (double)h, 1.0, 200.0);
}


int main(int argc, char** argv)
 {
	//Initialize GLUT
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(500, 500);
	glutInitWindowPosition(
                        (glutGet(GLUT_SCREEN_WIDTH)-640)/2,
                        (glutGet(GLUT_SCREEN_HEIGHT)-480)/2);

	//Create the window
	glutCreateWindow("Moving Car Re-factored");

    // Renderer class
    Renderer rdr;
	rdr.initRendering();

	//Set handler functions
	glutDisplayFunc(drawScene);

	glutReshapeFunc(handleResize);

	glutTimerFunc(25, update, 0); //Add a timer

	glutMainLoop();
	return 0;
}


