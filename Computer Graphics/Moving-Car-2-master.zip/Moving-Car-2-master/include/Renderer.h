#ifndef RENDERER_H
#define RENDERER_H
#include <iostream>
#include <stdlib.h>
#include <math.h>
#include<GL/gl.h>
#include <GL/glut.h>

using namespace std;
class Renderer
{
    public:
        Renderer();
        void initRendering();


};

#endif // RENDERER_H
