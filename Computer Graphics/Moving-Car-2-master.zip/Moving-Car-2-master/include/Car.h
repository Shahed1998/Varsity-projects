#ifndef CAR_H
#define CAR_H
#include <iostream>
#include <stdlib.h>
#include <math.h>
#include<GL/gl.h>
#include <GL/glut.h>

using namespace std;
class Car
{
    public:
        Car();
        Car(float _angle, float xAxis);

};

#endif // CAR_H
