#include "Renderer.h"

Renderer::Renderer()
{
    //ctor
}

void Renderer::initRendering() {
    glEnable(GL_DEPTH_TEST);
}
