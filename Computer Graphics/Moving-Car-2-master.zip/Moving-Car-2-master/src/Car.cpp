#include "Car.h"

Car::Car()
{
    //ctor
}

Car::Car(float _angle, float xAxis){
        glPushMatrix();
            glColor3f(1.0, 1.0, 1.0);
            glTranslatef(xAxis,0.0,0.0);
            glPushMatrix();
                glTranslatef(-1.6,0.0,0.0);
                glRotatef(_angle, 0.0, 0.0, -1.0);
                glutWireTorus(0.1, 0.15, 30, 30);
            glPopMatrix();
            glPushMatrix();
                glTranslatef(-0.5,0.0,0.0);
                glRotatef(_angle, 0.0, 0.0, -1.0);
                glutWireTorus(0.1, 0.15, 30, 30);
            glPopMatrix();
            // Body
            glPushMatrix();
                glBegin(GL_LINE_LOOP);
                    glVertex2f(-2.0, 0.0);
                    glVertex2f(0.0,0.0);
                    glVertex2f(0.0, 0.5);
                    glVertex2f(-0.5, 0.5);
                    glVertex2f(-0.5,1.0);
                    glVertex2f(-2.0,1.0);
                glEnd();
            glPopMatrix();

            //Window
            glPushMatrix();
                glBegin(GL_LINES);
                    glVertex2f(-2.0,0.5);
                    glVertex2f(-0.5,0.5);
                glEnd();
            glPopMatrix();
            glPushMatrix();
                glBegin(GL_LINES);
                    glVertex2f(-1.0,1.0);
                    glVertex2f(-1.0,0.5);
                glEnd();
            glPopMatrix();

            // Front Bulb
            glPushMatrix();
                glColor3f(1.0, 1.0, 0.0);
                glBegin(GL_POLYGON);
                    glVertex3f(-0.25, 0.25, 0.0);
                    glVertex3f(0.0, 0.25, 0.0);
                    glVertex3f(0.0, 0.35, 0.0);
                    glVertex3f(-0.25, 0.35, 0.0);
                glEnd();
            glPopMatrix();

        glPopMatrix();
}
