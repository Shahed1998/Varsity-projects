﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Data.SqlClient;

namespace Lab_Task_3
{
    public partial class login : Form
    {
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""S:\Varsity\OOP2\Final\Tasks\Lab Task 3\DB\labTask3.mdf"";Integrated Security=True;Connect Timeout=30");
        string pattern = "^([0-9a-zA-Z]([-\\.\\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\\w]*[0-9a-zA-Z]\\.)+[a-zA-Z]{2,9})$";
        public login()
        {
            InitializeComponent();
        }

        private void email_Click(object sender, EventArgs e)
        {

        }

        private void loginButton_Click(object sender, EventArgs e)
        {
            string email = emailTextBox.Text;
            string password = passwordTextBox.Text;
            conn.Open();
                SqlCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = $"SELECT * FROM USERS WHERE email='{email}' AND password = '{password}'";
                cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);

            if(dt.Rows.Count == 1)
            {
                SqlDataReader sdr = cmd.ExecuteReader();
                sdr.Read();
                Dashboard dash = new Dashboard(sdr["username"].ToString());
                dash.Tag = this;
                dash.Show(this);
                this.Hide();
            }
            else
            {
                MessageBox.Show("Invalid User");
            }

            conn.Close();
        }

        private void loginButton_Leave(object sender, EventArgs e)
        {

        }

        private void emailTextBox_Leave(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(emailTextBox.Text))
            {
                emailTextBox.Focus();
                emailErrorProvider.SetError(this.emailTextBox, "Please enter your email");
            }
            else if(! Regex.IsMatch(emailTextBox.Text, pattern))
            {
                emailTextBox.Focus();
                emailErrorProvider.SetError(this.emailTextBox, "Invalid email format");
            }
            else
            {
                emailErrorProvider.Clear();
            }
        }

        private void passwordTextBox_Leave(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(passwordTextBox.Text))
            {
                passwordTextBox.Focus();
                passwordErrorProvider.SetError(this.passwordTextBox, "Please enter your password");
            }
            else
            {
                passwordErrorProvider.Clear();
            }
        }
    }
}
