﻿CREATE TABLE USERS(

	userID int IDENTITY(1,1) PRIMARY KEY,
	username varchar(100) NOT NULL,
	email varchar(100) NOT NULL,
	password nvarchar(100) NOT NULL

)

INSERT INTO USERS VALUES 
('abcde', 'abcde@gmail.com', 'abcde'),
('qwerty', 'qwerty@gmail.com', 'qwerty')


