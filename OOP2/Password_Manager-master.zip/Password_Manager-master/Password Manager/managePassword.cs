﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Password_Manager.Classes;

namespace Password_Manager
{
    public partial class managePassword : Form
    {
        int id;
        int rowIndex = -1, passID;
        SqlConnection conn = new SqlConnection(connectString.Connect());

        void validator(string msg)
        {
            string message = msg;
            string title = "Warning";
            MessageBox.Show(message, title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        void loadDataGrid()
        {
            string getAllPass = $"SELECT * FROM allPasswords WHERE userID={id}";
            
            SqlDataAdapter sda = new SqlDataAdapter(getAllPass, conn);
            DataTable dtbl = new DataTable();
            sda.Fill(dtbl);
            passwordViewer.AutoGenerateColumns = false;
            passwordViewer.DataSource = dtbl;
            
        }

        public managePassword()
        {
            InitializeComponent();
        }

        public managePassword(int id)
        {
            InitializeComponent();
            this.id = id;
        }

        private void managePassword_Load(object sender, EventArgs e)
        {
            //MessageBox.Show($"{id}");
            conn.Open();
            loadDataGrid();
            conn.Close();
        }

        private void managePassword_FormClosing(object sender, FormClosingEventArgs e)
        {
            var dash = (dashboard)Tag;
            dash.Show();
        }

        private void createPass_Click(object sender, EventArgs e)
        {
            string app_name = appName.Text.Trim();
            string pass = password.Text.Trim(); 
            conn.Open();
            string insertQuery = "INSERT INTO allPasswords (appName, password, userID)" +
                $"VALUES ('{app_name}', '{pass}', '{id}')";
            SqlCommand cmd = new SqlCommand(insertQuery, conn);
            if(string.IsNullOrEmpty(app_name) || string.IsNullOrEmpty(pass))
            {
                validator("Select a row");
            }
            else if (cmd.ExecuteNonQuery() == 1)
            {
                loadDataGrid();
                MessageBox.Show("App name and password inserted successfully", "Success",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                rowIndex = -1;
                appName.Text = "";
                password.Text = "";

            }
            else
            {
                validator("Couldn't insert user");
            }


            conn.Close();
        }

        private void passwordViewer_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void passwordViewer_CellClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void updatePass_Click(object sender, EventArgs e)
        {
            //MessageBox.Show($"{rowIndex}");
            if(rowIndex == -1)
            {
                validator("Select a row");
            }
            else
            {
                string app_name = appName.Text.Trim();
                string pass = password.Text.Trim();
                rowIndex = rowIndex+1;
                string query = $"UPDATE allPasswords SET appName = '{app_name}'," +
                    $" password = '{pass}' WHERE userID= {id} AND passwordID={passID}";
                try
                {
                   // MessageBox.Show($"{id}\n {passID}");
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    loadDataGrid();
                    MessageBox.Show("Successfully updated password and app name", "Success",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                    rowIndex -= 1;
                    conn.Close();
                    rowIndex = -1;
                    appName.Text = "";
                    password.Text = "";

                }
                catch(Exception ex)
                {
                    validator($"Can't update password or appName\n {ex}");
                }
                
                
            }

        }

        private void deletePass_Click(object sender, EventArgs e)
        {
            //MessageBox.Show($"{rowIndex}");
            if (rowIndex == -1)
            {
                validator("Select a row");
            }
            else
            {
                string app_name = appName.Text.Trim();
                string pass = password.Text.Trim();
                rowIndex = rowIndex + 1;
                string query = $" Delete from allPasswords WHERE passwordID={passID}";
                try
                {
                    // MessageBox.Show($"{id}\n {passID}");
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    loadDataGrid();
                    MessageBox.Show("Successfully deleted password", "Success",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                    rowIndex -= 1;
                    conn.Close();
                    rowIndex = -1;
                    appName.Text = "";
                    password.Text = "";
                }
                catch (Exception ex)
                {
                    validator($"Can't update password or appName\n {ex}");
                }


            }
        }

        private void goBack_Click(object sender, EventArgs e)
        {
            var dash = (dashboard)Tag;
            dash.Show();
            this.Close();
        }

        private void passwordViewer_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if(e.RowIndex >= 0)
            {
                rowIndex = e.RowIndex;
                DataGridViewRow dgvr = passwordViewer.Rows[e.RowIndex];
                passID = Int32.Parse(dgvr.Cells[0].Value.ToString());
                appName.Text = dgvr.Cells[1].Value.ToString();
                password.Text = dgvr.Cells[2].Value.ToString();
            }
        }
    }
}
