﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using Password_Manager.Classes;

namespace Password_Manager
{
    public partial class registration : Form
    {
        void validator(string msg)
        {
            string message = msg;
            string title = "Warning";
            MessageBox.Show(message, title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        public registration()
        {
            InitializeComponent();
        }

        private void goBack_Click(object sender, EventArgs e)
        {
            var reg = (home)Tag;
            reg.Show();
            this.Close();
        }

        private void register_Click(object sender, EventArgs e)
        {
            string pattern = "^([0-9a-zA-Z]([-\\.\\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\\w]*[0-9a-zA-Z]\\.)+[a-zA-Z]{2,9})$";
            if (string.IsNullOrEmpty(username.Text) || 
               string.IsNullOrEmpty(email.Text) ||
               string.IsNullOrEmpty(password.Text))
            {
                validator("Fill up all the input fields");
            }
            else if(! Regex.IsMatch(email.Text,pattern))
            {
                validator("Invalid email format");
            }
            else if( !(password.Text.Length < 11))
            {
                validator("Password must be less than 11 characters");
            }
            else
            {
                string name = username.Text.Trim();
                string mail = email.Text.Trim();
                string pass = password.Text.Trim();
                string role = "member";

                SqlConnection conn = new SqlConnection(connectString.Connect());
                conn.Open();
                string insertQuery = "INSERT INTO Users (userName, email, password, roles)" +
                    $"VALUES ('{name}', '{mail}', '{pass}', '{role}' )";
                SqlCommand cmd = new SqlCommand(insertQuery, conn);
                if(cmd.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("User inserted successfully", "Success",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    validator("Couldn't insert user");
                }
                

                conn.Close();
            }
        }

        private void registration_FormClosing(object sender, FormClosingEventArgs e)
        {
            var reg = (home)Tag;
            reg.Show();
            
        }

        private void registration_Load(object sender, EventArgs e)
        {

        }
    }
}
