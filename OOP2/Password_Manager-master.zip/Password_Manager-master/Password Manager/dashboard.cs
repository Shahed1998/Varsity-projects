﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Password_Manager
{
    
    public partial class dashboard : Form
    {
        string name, mail, pass, role;
        int id;

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void usernameLabel_Click(object sender, EventArgs e)
        {

        }

        private void goBack_Click(object sender, EventArgs e)
        {
            var login = (loginPage)Tag;
            var home = (home)login.Tag;
            login.Close();
            home.Show();
        }

        private void dashboard_FormClosing(object sender, FormClosingEventArgs e)
        {
            var login = (loginPage)Tag;
            var home = (home)login.Tag;
            home.Show();
        }

        private void viewInfo_Click(object sender, EventArgs e)
        {
            managePassword mp = new managePassword(id);
            mp.Tag = this;
            mp.Show(this);
            this.Hide();
        }

        private void viewPasswords_Click(object sender, EventArgs e)
        {
            managePassword mp = new managePassword(id);
            mp.Tag = this;
            mp.Show(this);
            this.Hide();
        }

        
        public dashboard()
        {
            InitializeComponent();

        }

        public dashboard(int id, string name, string mail, string pass, string role)
        {
            InitializeComponent();
            this.name = name;
            this.id = id;
            this.mail = mail;
            this.pass = pass;
            this.role = role;

            usernameLabel.Text = this.name;
        }
    }
}
