﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Password_Manager.Classes;
using System.Data.SqlClient;

namespace Password_Manager
{
    public partial class loginPage : Form
    {
        void validator(string msg)
        {
            string message = msg;
            string title = "Warning";
            MessageBox.Show(message, title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        public loginPage()
        {
            InitializeComponent();
        }

        private void goBack_Click(object sender, EventArgs e)
        {
            var lp = (home)Tag;
            lp.Show();
            this.Hide();
        }

        private void login_Click(object sender, EventArgs e)
        {
            string mail = email.Text.Trim();
            string pass = password.Text.Trim();

            if(string.IsNullOrEmpty(mail) || string.IsNullOrEmpty(pass))
            {
                validator("Fill up all the input fields");
            }else
            {
                string selectQuery = $"SELECT * FROM Users WHERE email='{mail}' and password='{pass}'";
                SqlConnection conn = new SqlConnection(connectString.Connect());
                conn.Open();
                SqlCommand cmd = new SqlCommand(selectQuery, conn);
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(dt);

                if(dt.Rows.Count == 1)
                {
                    SqlDataReader sdr = cmd.ExecuteReader();
                    sdr.Read();

                    mail = sdr["email"].ToString();
                    pass = sdr["password"].ToString();
                    string name = sdr["userName"].ToString();
                    int id = Int32.Parse(sdr["userID"].ToString());
                    string role = sdr["roles"].ToString();

                    dashboard dash = new dashboard(id, name, mail, pass, role);
                    dash.Tag = this;
                    dash.Show(this);
                    this.Hide();
                }
                else
                {
                    validator("User not found");
                }
                conn.Close();
            }
        }

        private void loginPage_FormClosing(object sender, FormClosingEventArgs e)
        {
            var lp = (home)Tag;
            lp.Show();
            this.Hide();
        }
    }
}
