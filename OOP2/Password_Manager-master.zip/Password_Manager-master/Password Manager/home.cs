﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Password_Manager
{
    public partial class home : Form
    {
        public home()
        {
            InitializeComponent();
        }

        private void login_Click(object sender, EventArgs e)
        {
            loginPage lp = new loginPage();
            lp.Tag = this;
            lp.Show(this);
            this.Hide();
        }

        private void register_Click(object sender, EventArgs e)
        {
            registration reg = new registration();
            reg.Tag = this;
            reg.Show(this);
            this.Hide();
        }
    }
}
