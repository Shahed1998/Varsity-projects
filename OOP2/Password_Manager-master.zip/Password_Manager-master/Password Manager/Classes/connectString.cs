﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Password_Manager.Classes
{
    class connectString
    {
        private static string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""S:\Projects\Password Manager\DB\passwordManager.mdf"";Integrated Security=True;Connect Timeout=30";

        public static string Connect()
        {
            return connectionString;
        }
    }
}
