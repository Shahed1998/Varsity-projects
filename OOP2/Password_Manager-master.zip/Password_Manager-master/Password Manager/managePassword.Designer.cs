﻿
namespace Password_Manager
{
    partial class managePassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(managePassword));
            this.passwordViewer = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.updatePass = new System.Windows.Forms.Button();
            this.createPass = new System.Windows.Forms.Button();
            this.password = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.appName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.deletePass = new System.Windows.Forms.Button();
            this.goBack = new System.Windows.Forms.Button();
            this.indexNum = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pass = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.passwordViewer)).BeginInit();
            this.SuspendLayout();
            // 
            // passwordViewer
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.passwordViewer.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.passwordViewer.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.passwordViewer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.passwordViewer.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.indexNum,
            this.name,
            this.pass});
            this.passwordViewer.Location = new System.Drawing.Point(12, 41);
            this.passwordViewer.Name = "passwordViewer";
            this.passwordViewer.Size = new System.Drawing.Size(342, 258);
            this.passwordViewer.TabIndex = 1;
            this.passwordViewer.VirtualMode = true;
            this.passwordViewer.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.passwordViewer_CellClick);
            this.passwordViewer.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.passwordViewer_CellEnter);
            this.passwordViewer.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.passwordViewer_CellMouseDoubleClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label1.Location = new System.Drawing.Point(479, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(158, 25);
            this.label1.TabIndex = 3;
            this.label1.Text = "Password View";
            // 
            // updatePass
            // 
            this.updatePass.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updatePass.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.updatePass.Location = new System.Drawing.Point(526, 213);
            this.updatePass.Name = "updatePass";
            this.updatePass.Size = new System.Drawing.Size(111, 35);
            this.updatePass.TabIndex = 14;
            this.updatePass.Text = "Update";
            this.updatePass.UseVisualStyleBackColor = true;
            this.updatePass.Click += new System.EventHandler(this.updatePass_Click);
            // 
            // createPass
            // 
            this.createPass.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.createPass.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.createPass.Location = new System.Drawing.Point(406, 213);
            this.createPass.Name = "createPass";
            this.createPass.Size = new System.Drawing.Size(101, 35);
            this.createPass.TabIndex = 13;
            this.createPass.Text = "Add";
            this.createPass.UseVisualStyleBackColor = true;
            this.createPass.Click += new System.EventHandler(this.createPass_Click);
            // 
            // password
            // 
            this.password.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.password.Location = new System.Drawing.Point(492, 149);
            this.password.Name = "password";
            this.password.PasswordChar = '*';
            this.password.Size = new System.Drawing.Size(145, 31);
            this.password.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label3.Location = new System.Drawing.Point(380, 149);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 25);
            this.label3.TabIndex = 11;
            this.label3.Text = "Password";
            // 
            // appName
            // 
            this.appName.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.appName.Location = new System.Drawing.Point(492, 97);
            this.appName.Name = "appName";
            this.appName.Size = new System.Drawing.Size(145, 31);
            this.appName.TabIndex = 10;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label2.Location = new System.Drawing.Point(377, 100);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 25);
            this.label2.TabIndex = 9;
            this.label2.Text = "App name";
            // 
            // deletePass
            // 
            this.deletePass.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deletePass.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.deletePass.Location = new System.Drawing.Point(406, 264);
            this.deletePass.Name = "deletePass";
            this.deletePass.Size = new System.Drawing.Size(101, 35);
            this.deletePass.TabIndex = 15;
            this.deletePass.Text = "Delete";
            this.deletePass.UseVisualStyleBackColor = true;
            this.deletePass.Click += new System.EventHandler(this.deletePass_Click);
            // 
            // goBack
            // 
            this.goBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.goBack.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.goBack.Location = new System.Drawing.Point(526, 264);
            this.goBack.Name = "goBack";
            this.goBack.Size = new System.Drawing.Size(111, 35);
            this.goBack.TabIndex = 16;
            this.goBack.Text = "Go Back";
            this.goBack.UseVisualStyleBackColor = true;
            this.goBack.Click += new System.EventHandler(this.goBack_Click);
            // 
            // indexNum
            // 
            this.indexNum.DataPropertyName = "passwordID";
            this.indexNum.HeaderText = "Password_ID";
            this.indexNum.Name = "indexNum";
            // 
            // name
            // 
            this.name.DataPropertyName = "appName";
            this.name.HeaderText = "App";
            this.name.Name = "name";
            // 
            // pass
            // 
            this.pass.DataPropertyName = "password";
            this.pass.HeaderText = "Password";
            this.pass.Name = "pass";
            // 
            // managePassword
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(719, 361);
            this.Controls.Add(this.goBack);
            this.Controls.Add(this.deletePass);
            this.Controls.Add(this.updatePass);
            this.Controls.Add(this.createPass);
            this.Controls.Add(this.password);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.appName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.passwordViewer);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "managePassword";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Password Manager [ Manage Password ]";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.managePassword_FormClosing);
            this.Load += new System.EventHandler(this.managePassword_Load);
            ((System.ComponentModel.ISupportInitialize)(this.passwordViewer)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView passwordViewer;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button updatePass;
        private System.Windows.Forms.Button createPass;
        private System.Windows.Forms.TextBox password;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox appName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button deletePass;
        private System.Windows.Forms.Button goBack;
        private System.Windows.Forms.DataGridViewTextBoxColumn indexNum;
        private System.Windows.Forms.DataGridViewTextBoxColumn name;
        private System.Windows.Forms.DataGridViewTextBoxColumn pass;
    }
}