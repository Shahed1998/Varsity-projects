﻿DROP TABLE Users;
CREATE TABLE Users
(
	userID int identity(1,1) PRIMARY KEY,
	userName varchar(255) not null,
	email varchar(255) not null,
	password nvarchar(255) not null,
	roles varchar(255) not null
)
INSERT INTO Users (userName, email, password) VALUES ('efghi', 'efghi@gmail.com', 'efghi' );


CREATE TABLE allPasswords
(
	passwordID int identity(1,1) PRIMARY KEY,
	appName varchar(255) not null,
	password nvarchar(255) not null,
	userID int not null
)

INSERT INTO allPasswords (appName, password, userID) VALUES ('facebook', 'qwerty', 2); 