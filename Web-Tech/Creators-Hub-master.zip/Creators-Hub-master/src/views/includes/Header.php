<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../public/images/logo.ico" type="image/x-icon">
    <title>Creator's Hub</title>
</head>
<body>
<fieldset>
    <table>
        <tr>
            <td>
              <img src="../public/images/Logo.PNG" alt="Image not available" width="200" height="100">
                 <td>
                 <td><td><td><td><td> <h1 style="border:2px solid SlateBlue;" >CREATOR'S HUB</h1></td>
            </td>
            <td>

            </td>
        </tr>
    </table>    
</fieldset>