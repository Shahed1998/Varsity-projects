<fieldset>
    <b>    
        <label >
            <p style="text-align:center;">Copyright © 2022</P>
        </label>
    </b>
</fieldset>
</body>
</html>