import Heading from './components/Heading';

function App() {
  return <Heading></Heading>;
}

export default App;
