const Home = () => {
  return <h1>Ecommerce Website</h1>;
};

export default Home;
