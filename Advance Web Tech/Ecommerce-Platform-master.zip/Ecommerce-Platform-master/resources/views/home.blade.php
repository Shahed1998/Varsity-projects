@extends('layouts.home')
@section('content')
    <img src="{{asset('storage/images/07CIZxikBPpIeCO5RnRVt9z8rv854gCSr6aszlvo.jpg')}}" alt="">
@endsection