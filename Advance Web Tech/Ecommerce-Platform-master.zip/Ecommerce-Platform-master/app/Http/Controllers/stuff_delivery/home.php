<?php

namespace App\Http\Controllers\stuff_delivery;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class home extends Controller
{
    //
}
