<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Customer_cart extends Model
{
    use HasFactory;
    use HasFactory;
    protected $table = "customer_cart";
    public $timestamps = false;
}
