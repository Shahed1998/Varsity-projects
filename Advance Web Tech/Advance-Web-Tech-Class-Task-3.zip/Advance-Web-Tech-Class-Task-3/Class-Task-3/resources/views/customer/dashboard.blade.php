@extends('layouts.customerLayout')
@section('content')
    <h2>Welcome {{$customer_name}}</h2>
@endsection
