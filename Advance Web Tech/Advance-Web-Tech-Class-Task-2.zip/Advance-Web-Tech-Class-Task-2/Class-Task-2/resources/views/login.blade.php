@extends('layouts.basic')
@section('content')
    <a href="/dashboard/student">Student dashboard</a><br>
    <a href="/dashboard/admin">Admin dashboard</a><br><br>
@endsection
